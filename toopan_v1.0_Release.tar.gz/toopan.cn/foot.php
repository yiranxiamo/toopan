</script>
<script src='https://cdn.jsdelivr.net/gh/HCLonely/Valine@latest/dist/Valine.min.js'></script>
<div id="vcomments"></div>
<script>
    new Valine({
        el: '#vcomments',
        appId: 'i5Vv8Tf5tv4GTUsXil6mtzlM-gzGzoHsz',
        appKey: 'Sqai6FV8ffhb0YHuqDcd7bo7',
        avatar:'wavatar',
        placeholder:'发表评论，填入QQ邮箱显示头像噢',
        lang:'zh-cn'
    })
</script>
<br>
<br>
<br>