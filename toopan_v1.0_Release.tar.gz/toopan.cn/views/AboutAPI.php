<?php
include("./includes/common.php");
include SYSTEM_ROOT.'header.php';
?>

<style type="text/css">
</style>
<div class="container">
<div class="well bs-component">
<div class="panel-title" style="font:20px Microsoft YaHei; margin:0px auto; text-align:center;">
<font color="#696969"><h2>api使用</h2><hr/>
</div>
<p>API接口地址：https://www.toopan.cn/api.php</p>
<p>当前API支持JSON、JSONP、FORM 3种返回方式，支持Web跨域调用，也支持程序中直接调用。</p>
<p>请求方式：POST  multipart/form-data</p>

</div>
</div>
</div>
<script src="assets/js/upload.js?v=1001"></script>
<?php include SYSTEM_ROOT.'footer.php';?>